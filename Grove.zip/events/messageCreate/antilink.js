const { PermissionFlagsBits } = require('discord.js')
const GuildConfig = require('../../database/models/antilink.js')


const linkRegex = /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/;

module.exports = {
    name: 'messageCreate',
    async execute(message) {

        if (message.author.bot || !message.guild) return;

        const guildId = message.guild.id;
        const guildConfig = await GuildConfig.findOne({ guildId })

        if (guildConfig && guildConfig.antilinkEnabled) {
            const allowedRoles = guildConfig.allowedRoles;

            if (linkRegex.test(message.content)) {
                const hasAdminPermission = message.member.permissions.has(PermissionFlagsBits.Administrator)
                const hasAllowedRole = allowedRoles.some(roleId => message.member.roles.cache.has(roleId))

                if (hasAdminPermission || hasAllowedRole) return;

                await message.delete()
                try {
                    const alertMessage = await message.channel.send(`> \`-\` <a:alerta:1163274838111162499> ${message.author}, links não são permitidos em **${message.guild.name}**`);
                    setTimeout(() => alertMessage.delete(), 15000)
                } catch (error) {
                    console.error("Erro ao enviar mensagem de alerta:", error)
                }
            }
        }
    }
}
